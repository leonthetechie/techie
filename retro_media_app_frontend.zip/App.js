
import React, { useState, useEffect } from 'react';
import './App.css';

const App = () => {
  const [file, setFile] = useState(null);
  const [media, setMedia] = useState([]);

  useEffect(() => {
    fetch('https://techie-5v68.onrender.com/media')
      .then((res) => res.json())
      .then((data) => setMedia(data));
  }, []);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('https://techie-5v68.onrender.com/upload', {
        method: 'POST',
        body: formData,
      });
      const result = await response.json();
      setMedia([...media, { name: file.name, url: result.url }]);
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  };

  return (
    <div className="App">
      <h1>Retro Media App</h1>
      <form onSubmit={handleUpload}>
        <input
          type="file"
          onChange={(e) => setFile(e.target.files[0])}
          required
        />
        <button type="submit">Upload</button>
      </form>
      <div className="media-list">
        {media.map((item, index) => (
          <div key={index} className="media-item">
            <p>{item.name}</p>
            <a href={item.url} target="_blank" rel="noopener noreferrer">
              View/Download
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
