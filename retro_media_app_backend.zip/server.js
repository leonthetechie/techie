
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const { create } = require('ipfs-http-client');

const app = express();
const upload = multer();
const ipfs = create({ host: 'ipfs.infura.io', port: 5001, protocol: 'https' });

app.use(cors());
app.use(express.json());

let mediaMetadata = [];

// Upload endpoint
app.post('/upload', upload.single('file'), async (req, res) => {
    try {
        const file = req.file;
        if (!file) {
            return res.status(400).send('No file uploaded.');
        }
        const added = await ipfs.add(file.buffer);
        const fileUrl = `https://ipfs.io/ipfs/${added.path}`;
        
        mediaMetadata.push({ name: file.originalname, url: fileUrl });
        res.send({ url: fileUrl });
    } catch (error) {
        res.status(500).send('Error uploading file to IPFS.');
    }
});

// Fetch metadata endpoint
app.get('/media', (req, res) => {
    res.json(mediaMetadata);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
